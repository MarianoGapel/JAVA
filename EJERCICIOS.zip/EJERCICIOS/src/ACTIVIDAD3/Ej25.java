package ACTIVIDAD3;
import java.util.Scanner;

/*
 * 25. Realiz� un programa que permita ingresar dos n�meros enteros que representen el ancho y
el alto de una matriz de cruces. El programa debe dibujar dicha matriz.
 */
public class Ej25 {
	final static Scanner input = new Scanner (System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
